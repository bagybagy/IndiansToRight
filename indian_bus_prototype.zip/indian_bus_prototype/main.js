import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.165.0/build/three.module.js';

const canvas = document.querySelector('#scene');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf5c542);
scene.fog = new THREE.Fog(0xf5c542, 20, 60);

const camera = new THREE.PerspectiveCamera(42, window.innerWidth / window.innerHeight, 0.1, 100);
camera.position.set(7.2, 4.3, 9.6);
camera.lookAt(0, 1.2, 0);

const hemi = new THREE.HemisphereLight(0xffffff, 0x9b6d1f, 2.0);
scene.add(hemi);
const dir = new THREE.DirectionalLight(0xffffff, 2.6);
dir.position.set(4, 8, 5);
dir.castShadow = true;
scene.add(dir);

const root = new THREE.Group();
scene.add(root);

const busGroup = new THREE.Group();
root.add(busGroup);

const matBus = new THREE.MeshStandardMaterial({ color: 0xff7a1a, roughness: 0.62, metalness: 0.05 });
const matBusDark = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.7 });
const matWindow = new THREE.MeshStandardMaterial({ color: 0x7dd3fc, roughness: 0.25, metalness: 0.1 });
const matTire = new THREE.MeshStandardMaterial({ color: 0x191919, roughness: 0.8 });
const matWhite = new THREE.MeshStandardMaterial({ color: 0xf9fafb, roughness: 0.72 });
const matSkin = new THREE.MeshStandardMaterial({ color: 0x8f5130, roughness: 0.65 });
const matTurban = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.62 });
const matAccent = new THREE.MeshStandardMaterial({ color: 0xe32b1f, roughness: 0.6 });

function mesh(geo, mat, pos, rot = [0,0,0], scale = [1,1,1], parent = scene) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(...pos);
  m.rotation.set(...rot);
  m.scale.set(...scale);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

// Road and moving stripe illusion
const road = mesh(new THREE.BoxGeometry(80, .08, 10), new THREE.MeshStandardMaterial({ color: 0x222222 }), [0, -0.08, 0], [0,0,0], [1,1,1], scene);
road.receiveShadow = true;
const stripes = [];
for (let i = 0; i < 18; i++) {
  const s = mesh(new THREE.BoxGeometry(1.4, .09, .08), new THREE.MeshStandardMaterial({ color: 0xffffff }), [i * 4 - 34, -0.02, -3.4], [0,0,0], [1,1,1], scene);
  stripes.push(s);
}

// Bus body: cutaway side so cabin passengers are visible
const body = mesh(new THREE.BoxGeometry(5.6, 2.0, 2.25), matBus, [0, 1.1, 0], [0,0,0], [1,1,1], busGroup);
const cabinHole = mesh(new THREE.BoxGeometry(5.15, 1.38, .07), new THREE.MeshBasicMaterial({ color: 0xfef3c7 }), [0, 1.22, 1.16], [0,0,0], [1,1,1], busGroup);
cabinHole.castShadow = false;
const roof = mesh(new THREE.BoxGeometry(5.9, .22, 2.45), matBusDark, [0, 2.22, 0], [0,0,0], [1,1,1], busGroup);
const front = mesh(new THREE.BoxGeometry(.35, 1.82, 2.28), matWindow, [2.98, 1.25, 0], [0,0,0], [1,1,1], busGroup);
for (const x of [-2.1, -1.05, 0, 1.05, 2.1]) {
  mesh(new THREE.BoxGeometry(.72, .58, .08), matWindow, [x, 1.52, -1.16], [0,0,0], [1,1,1], busGroup);
}
for (const x of [-2.15, 2.1]) {
  const tire = mesh(new THREE.CylinderGeometry(.45, .45, .34, 32), matTire, [x, .16, 1.15], [Math.PI/2,0,0], [1,1,1], busGroup);
  mesh(new THREE.CylinderGeometry(.28, .28, .36, 32), new THREE.MeshStandardMaterial({ color: 0x777777 }), [x, .16, 1.16], [Math.PI/2,0,0], [1,1,1], busGroup);
}

// decorative arrows
const arrowGroup = new THREE.Group();
scene.add(arrowGroup);
for (let i = 0; i < 5; i++) {
  const a = mesh(new THREE.ConeGeometry(.35, .85, 3), matAccent, [-6 + i * 1.15, 3.65, -1.8], [0,0,-Math.PI/2], [1,1,1], arrowGroup);
  a.castShadow = false;
}

const passengers = [];
const passengerRoot = new THREE.Group();
busGroup.add(passengerRoot);

function createPassenger(i) {
  const g = new THREE.Group();
  const body = mesh(new THREE.CapsuleGeometry(.12, .38, 3, 8), matWhite, [0, .28, 0], [0,0,0], [1,1,1], g);
  const head = mesh(new THREE.SphereGeometry(.13, 12, 8), matSkin, [0, .64, 0], [0,0,0], [1,1,1], g);
  const turban = mesh(new THREE.TorusGeometry(.12, .035, 8, 14), matTurban, [0, .74, 0], [Math.PI/2,0,0], [1,1,1], g);
  const armL = mesh(new THREE.CapsuleGeometry(.035, .28, 2, 6), matSkin, [-.14, .35, 0], [0,0,.35], [1,1,1], g);
  const armR = mesh(new THREE.CapsuleGeometry(.035, .28, 2, 6), matSkin, [.14, .35, 0], [0,0,-.35], [1,1,1], g);
  g.userData.parts = { body, head, turban, armL, armR };
  passengerRoot.add(g);

  const area = pickArea(i);
  const p = {
    group: g,
    area,
    side: THREE.MathUtils.randFloatSpread(1.1),
    targetSide: 0,
    depth: THREE.MathUtils.randFloatSpread(1.4),
    heightJitter: Math.random(),
    weight: THREE.MathUtils.randFloat(.85, 1.25),
    phase: Math.random() * Math.PI * 2,
    size: THREE.MathUtils.randFloat(.85, 1.12),
    panic: Math.random(),
    active: true
  };
  g.scale.setScalar(p.size);
  passengers.push(p);
  return p;
}

function pickArea(i) {
  if (i < 74) return 'cabin';
  if (i < 105) return 'window';
  if (i < 132) return 'roof';
  return 'side';
}

for (let i = 0; i < 150; i++) createPassenger(i);
let activeCount = 80;
let nextCurve = 1; // 1 right, -1 left
let commandSide = 0;
let roofBias = 0;
let resultFlash = 0;
let danceMode = false;

function updatePassengerTargets() {
  passengers.forEach((p, i) => {
    p.active = i < activeCount;
    p.group.visible = p.active;
    const crowdFactor = activeCount / 150;
    const baseSpread = p.area === 'cabin' ? 1.25 : p.area === 'roof' ? 1.55 : 1.75;
    const compression = Math.max(0, crowdFactor - .45) * .55;
    p.targetSide = THREE.MathUtils.clamp(commandSide * baseSpread + THREE.MathUtils.randFloatSpread(.32 - Math.min(.22, compression)), -1.85, 1.85);
    if (p.area === 'roof') p.targetSide += commandSide * .22;
    if (p.area === 'side') p.targetSide += commandSide * .35;
  });
}
updatePassengerTargets();

function passengerPosition(p, t) {
  const crowdFactor = activeCount / 150;
  const side = p.side;
  const pressure = Math.max(0, Math.abs(side) - .7) * crowdFactor;
  const wave = Math.sin(t * 6 + p.phase) * .035;
  let x = side * 1.35;
  let y = 0.56;
  let z = p.depth;

  if (p.area === 'cabin') {
    y = 0.43 + (p.heightJitter % .45) * .6 + pressure * .25;
    z = THREE.MathUtils.clamp(p.depth, -.82, .86);
  } else if (p.area === 'window') {
    y = 1.05 + (p.heightJitter * .45) + pressure * .36;
    z = 1.02 + Math.abs(side) * .22 + pressure * .34;
    x *= 1.08;
  } else if (p.area === 'roof') {
    y = 2.22 + (p.heightJitter * .72) + pressure * .55;
    z = THREE.MathUtils.clamp(p.depth, -.9, .9);
    x *= 1.25;
  } else if (p.area === 'side') {
    y = .75 + (p.heightJitter * .9) + pressure * .25;
    z = 1.28 + pressure * .5;
    x *= 1.38;
  }
  // Crammed side bulges outward/upward instead of aligning cleanly.
  x += commandSide * pressure * .22;
  y += wave;
  return new THREE.Vector3(x, y, z);
}

function animatePassenger(p, dt, t) {
  p.side = THREE.MathUtils.lerp(p.side, p.targetSide, 1 - Math.pow(.06, dt));
  const pos = passengerPosition(p, t);
  p.group.position.copy(pos);

  const speedLean = THREE.MathUtils.clamp((p.targetSide - p.side) * 2.2, -0.55, 0.55);
  const crowdDance = danceMode ? Math.sin(t * 11 + p.phase) * .18 : 0;
  p.group.rotation.z = -speedLean + Math.sin(t * 5 + p.phase) * .05 + crowdDance;
  p.group.rotation.y = Math.sin(t * 2.7 + p.phase) * .08;

  const parts = p.group.userData.parts;
  const moving = Math.abs(p.targetSide - p.side) > .08;
  const armSwing = moving ? Math.sin(t * 14 + p.phase) * .7 : Math.sin(t * 4 + p.phase) * .12;
  parts.armL.rotation.z = .35 + armSwing;
  parts.armR.rotation.z = -.35 - armSwing;
  if (p.area === 'side' || Math.abs(p.side) > 1.25) {
    parts.armL.rotation.z = 1.8 + Math.sin(t * 7 + p.phase) * .2;
    parts.armR.rotation.z = -1.8 + Math.cos(t * 7 + p.phase) * .2;
  }
  if (danceMode) {
    parts.armL.rotation.z = 2.1 + Math.sin(t * 12 + p.phase) * .45;
    parts.armR.rotation.z = -2.1 + Math.cos(t * 12 + p.phase) * .45;
  }
}

function calculateCOM() {
  let total = 40; // bus mass baseline
  let x = 0;
  let y = 0.65 * 40;
  for (const p of passengers) {
    if (!p.active) continue;
    const pos = p.group.position;
    total += p.weight;
    x += pos.x * p.weight;
    y += pos.y * p.weight;
  }
  return { x: x / total, y: y / total };
}

function judgeCurve() {
  const com = calculateCOM();
  const target = nextCurve * .36;
  const horizontalScore = 1 - Math.min(1, Math.abs(target - com.x) / 1.2);
  const heightPenalty = Math.max(0, com.y - 1.18) * .33;
  const stability = Math.round(Math.max(0, Math.min(1, horizontalScore - heightPenalty)) * 100);
  if (stability >= 62) {
    activeCount = Math.min(150, activeCount + 8 + Math.floor(Math.random() * 8));
    message.textContent = 'カーブ成功！ 乗客がさらに飛び乗った！';
    danceMode = activeCount >= 135;
  } else {
    activeCount = Math.max(35, activeCount - 10 - Math.floor(Math.random() * 16));
    message.textContent = '危ない！ 乗客が降りた！';
    danceMode = false;
  }
  nextCurve *= -1;
  resultFlash = 1;
  updatePassengerTargets();
}

const keys = new Set();
window.addEventListener('keydown', (e) => {
  if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space'].includes(e.code)) e.preventDefault();
  keys.add(e.code);
  if (e.code === 'Space') judgeCurve();
  if (e.code === 'KeyR') {
    activeCount = 80; nextCurve = 1; commandSide = 0; roofBias = 0; danceMode = false;
    passengers.forEach((p) => { p.side = THREE.MathUtils.randFloatSpread(1.1); p.area = pickArea(passengers.indexOf(p)); });
    message.textContent = '右カーブだ！ インド人を右に！';
    updatePassengerTargets();
  }
});
window.addEventListener('keyup', (e) => keys.delete(e.code));

const passengerCountEl = document.querySelector('#passengerCount');
const loadRateEl = document.querySelector('#loadRate');
const curveText = document.querySelector('#curveText');
const comText = document.querySelector('#comText');
const stabilityText = document.querySelector('#stabilityText');
const comBar = document.querySelector('#comBar');
const message = document.querySelector('#message');

let last = performance.now();
function animate(now) {
  const dt = Math.min(.05, (now - last) / 1000);
  last = now;
  const t = now / 1000;

  if (keys.has('ArrowLeft')) { commandSide = THREE.MathUtils.lerp(commandSide, -1, .08); updatePassengerTargets(); }
  if (keys.has('ArrowRight')) { commandSide = THREE.MathUtils.lerp(commandSide, 1, .08); updatePassengerTargets(); }
  if (!keys.has('ArrowLeft') && !keys.has('ArrowRight')) { commandSide = THREE.MathUtils.lerp(commandSide, 0, .022); updatePassengerTargets(); }
  if (keys.has('ArrowUp')) {
    const candidate = passengers.find(p => p.active && p.area === 'cabin' && Math.random() < .12);
    if (candidate) candidate.area = 'roof';
  }
  if (keys.has('ArrowDown')) {
    const candidate = passengers.find(p => p.active && (p.area === 'roof' || p.area === 'side') && Math.random() < .12);
    if (candidate) candidate.area = 'cabin';
  }

  for (const p of passengers) if (p.active) animatePassenger(p, dt, t);
  const com = calculateCOM();
  const target = nextCurve * .36;
  const horizontalScore = 1 - Math.min(1, Math.abs(target - com.x) / 1.2);
  const heightPenalty = Math.max(0, com.y - 1.18) * .33;
  const stability = Math.round(Math.max(0, Math.min(1, horizontalScore - heightPenalty)) * 100);

  const busLean = -com.x * .25 + nextCurve * .05 + Math.sin(t * 5) * .01;
  busGroup.rotation.z = THREE.MathUtils.lerp(busGroup.rotation.z, busLean, .12);
  busGroup.position.y = Math.sin(t * 9) * .025 - Math.abs(com.x) * .07;
  busGroup.position.x = Math.sin(t * 2) * .035;
  camera.position.x = 7.2 + Math.sin(t * 1.4) * .08 + resultFlash * THREE.MathUtils.randFloatSpread(.06);
  camera.lookAt(0, 1.2, 0);
  resultFlash = Math.max(0, resultFlash - dt * 1.8);

  for (const s of stripes) {
    s.position.x -= dt * (7 + activeCount / 18);
    if (s.position.x < -36) s.position.x += 72;
  }
  arrowGroup.position.x = Math.sin(t * 4) * .15;
  arrowGroup.rotation.z = nextCurve > 0 ? 0 : Math.PI;
  arrowGroup.position.x = nextCurve > 0 ? 0 : 2.0;

  passengerCountEl.textContent = activeCount;
  loadRateEl.textContent = Math.round(activeCount / 40 * 100);
  curveText.textContent = nextCurve > 0 ? '右' : '左';
  curveText.style.color = nextCurve > 0 ? '#e32b1f' : '#2563eb';
  comText.textContent = com.x.toFixed(2);
  stabilityText.textContent = stability;
  comBar.style.left = `${THREE.MathUtils.clamp(50 + com.x * 24, 6, 94)}%`;
  if (!resultFlash && !danceMode) {
    message.textContent = `${nextCurve > 0 ? '右' : '左'}カーブだ！ インド人を${nextCurve > 0 ? '右' : '左'}に！`;
  } else if (danceMode) {
    message.textContent = '満員！ 全員踊りだしてスピードアップ！';
  }

  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}
requestAnimationFrame(animate);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
